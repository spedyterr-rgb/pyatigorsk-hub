ПОЗЫВНОЙ: ТУМАН  v1.3
PYATIGORSK HUB. Developer — yarchi, Game Designer — Vlad Montana

Запуск: Tuman.exe
Кооператив: один создаёт отряд, второй вводит код. В разных сетях — Radmin VPN.
Telegram: https://t.me/shopyarchi
